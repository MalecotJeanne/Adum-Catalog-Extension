// ----------------------
// 1. Collect all <table> elements WITHOUT a class
// ----------------------
const tables = Array.from(document.querySelectorAll("table:not([class])"));

let tdList = [];

// 2. Collect all <td> from these tables
tables.forEach(table => {
  const tds = table.querySelectorAll("td:not([class])");
  tdList.push(...tds);
});

// 3. Convert NodeList → trimmed text list
tdList = tdList.map(td => td.textContent.trim());

// 4. Build "formation" objects, 6 <td> per object
let formations = [];
for (let i = 0; i < tdList.length; i += 6) {
  if (i + 5 >= tdList.length) break;
  formations.push({
    name: tdList[i],
    place: tdList[i + 1],
    date: tdList[i + 2],
    participation: tdList[i + 3],
    state: tdList[i + 4],
    places: tdList[i + 5]
  });
}

// ----------------------
// 5. Load saved formations and compare
// ----------------------
browser.storage.local.get("formations").then(result => {
  const saved = result.formations || [];

  // --- TEST MODE: randomly remove 5 saved formations for testing ---
  let savedFake = [...saved];  
  if (savedFake.length > 5) {
    for (let i = 0; i < 5; i++) {
      const index = Math.floor(Math.random() * savedFake.length);
      savedFake.splice(index, 1);
    }
    console.log("TEST: Randomly removed 5 saved formations:", savedFake);
  }

  const savedKeys = new Set(savedFake.map(f => `${f.name}|${f.place}|${f.date}`));

  // Find formations that are NOT in saved formations
  const newFormations = formations.filter(f => {
    const key = `${f.name}|${f.place}|${f.date}`;
    return !savedKeys.has(key);
  });

  console.log("New formations found only on the webpage:");
  console.log(newFormations);

  // ----------------------
  // 6. Prepare the container
  // ----------------------
  const container = document.createElement("div");
  container.style.background = "#e3f2fd";
  container.style.padding = "10px";
  container.style.borderBottom = "3px solid #64b5f6";
  container.style.fontFamily = "monospace";
  container.style.whiteSpace = "pre-wrap";
  container.style.visibility = "hidden"; // hide until inserted

  const title = document.createElement("h2");
  title.textContent = "New formations:";
  title.style.margin = "0 0 10px 0";
  container.appendChild(title);

  const pre = document.createElement("pre");
  pre.textContent = JSON.stringify(newFormations, null, 2);
  container.appendChild(pre);

  //TODO: insert at the correct place


});

// ----------------------
// 8. Save formations back to storage
// ----------------------
browser.storage.local.set({ formations })
  .then(() => console.log("Formations saved!"))
  .catch(err => console.error("Storage error:", err));
